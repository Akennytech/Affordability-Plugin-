<?php
  /**
   	 *Plugin Name: Affordability Calculator
   	 *Description: Custom Plugin
	 *Author: Amusa Kehinde
  */


if( !defined('ABSPATH') )
{
	echo '404';
	exit;
}

class Affordability{
	
	public function __construct()
{
  		  //Add assets (js, css)
  		  add_action('wp_enqueue_scripts', array($this, 'load_assets'));
			// Add Shortcode
		  add_shortcode('affordability', array($this, 'load_shortcode'));
}


public function load_assets()
{
   wp_enqueue_style(
                'affordability',
		plugin_dir_url( __FILE__ ) . 'css/affordability.css',
		array(),
		1,		
		'all'
             );
    wp_enqueue_script(
                'affordability',
		plugin_dir_url( __FILE__ ) . 'js/affordability.js',
		array('jquery'),
		1,		
		true
             );

}

public function load_shortcode()
{?>
   
 <!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Affordability Plugin</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>
<body>

<div class="container">
  <div class="html-code">

<div class="tabbed-form">
  <div class="tabs">
    <button id="defaultOpen" class="tab active" onclick="openTab(event, 'tab1')">Personal info</button>
    <button class="tab" onclick="openTab(event, 'tab2')">Taxes and fees</button>
  </div>

  <div id="tab1" class="tab-content">
    <p>The following fields are required</p>
    <form>
      <div class="form-field">
        <label for="income">Annual Income ($):</label>
        <div class="input-container">
          <input type="number" id="income" name="income" required>
          <button type="button" class="info-button" onclick="showInfo(event)">ℹ️</button>
        </div>
      </div>
      <div class="form-field">
        <label for="expenses">Current Monthly Debt ($):</label>
        <div class="input-container">
          <input type="number" id="expenses" name="expenses" required>
          <button type="button" class="info-button" onclick="showInfo(event)">ℹ️</button>
        </div>
      </div>
      <div class="form-field">
        <label for="downPayment">Down Payment ($):</label>
        <div class="input-container">
          <input type="number" id="downPayment" name="downPayment"  required>
          <button type="button" class="info-button" onclick="showInfo(event)">ℹ️</button>
        </div>
      </div>
      <div class="form-field  underline-style">
        <label for="state">State:</label>
  <select id="state" name="state" required>
    <option value=""></option>
    <option value="lagos">Lagos</option>
    <option value="abuja">Abuja</option>
    <option value="ogun">Ogun</option>
    <option value="london">London</option>
    <option value="usa">USA</option>
  </select>
</div>
      <br>
      <button type="button" class="calculate-button" onclick="calculate()">Calculate</button>
    </form>
  </div>

  <div id="tab2" class="tab-content" style="display:none">
    <form>
      <div class="form-field">
        <label for="propertyTax">Property Tax (Yearly) ($) :</label>
        <div class="input-container">
          <input type="number" id="propertyTax" name="propertyTax"  value="5000" required>
          <button type="button" class="info-button" onclick="showInfo(event)">ℹ️</button>
        </div>
      </div>
      <div class="form-field">
        <label for="homeownersInsurance">Homeowners Insurance (Yearly) ($):</label>
        <div class="input-container">
          <input type="number" id="homeownersInsurance" name="homeownersInsurance"  value="1200" required>
          
          <button type="button" class="info-button" onclick="showInfo(event)">ℹ️</button>
        </div>
      </div>
      <div class="form-field">
        <label for="hoaFees">Homeowners Association Fees (Monthly) ($):</label>
        <div class="input-container">
          <input type="number" id="hoaFees" name="hoaFees" value="0">
          <button type="button" class="info-button" onclick="showInfo(event)">ℹ️</button>
        </div>
      </div>
      <div class="form-field">
        <label for="years">Loan Term (Years):</label>
        <div class="input-container">
          <input type="text" id="years" name="years" value="30 years" required>
          <button type="button" class="info-button" onclick="showInfo(event)">ℹ️</button>
        </div>
      </div>
      <div class="form-field">
        <label for="interest">Interest Rate (%):</label>
        <div class="input-container">
          <input type="text" id="interest" step="0.01" name="interest" value="6.99" required>
          <button type="button" class="info-button" onclick="showInfo(event)">ℹ️</button>
        </div>
      </div>
      <button type="button" class="calculate-button" onclick="calculate()">Calculate</button>
    </form>
  </div>
</div>
   </div>
  <div class="javascript-result">
      <div>
        <div>
        <div id="myImage">
          <p><b>PIE CHART</b></p>
          <img src="https://cdn.sanity.io/images/599r6htc/regionalized/128e6a1b9aba13b48886e276b4c02e5c6c68ec01-1108x1108.png?w=1200&q=70&fit=max&auto=format"  alt="Placeholder Image" width="250" height="250">
          </div>
           <p>  Estimated monthly espenses <button id="infoButton">ℹ️</button></p>
          </div>
       
         <div style="width: 300px; height: 300px;">
    <canvas id="pieChart" width="100" height="100"></canvas>  
          </div>
    <div id="infoModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <div id="tot"></div>
        </div>
    </div>
      
        
        <br>
        <div id="result"></div>
  </div>
  </div>
    </body>

<?php  }

}

new Affordability;

