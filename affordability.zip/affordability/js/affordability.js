function numberWithCommas(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }

function calculate() {
    var income = parseFloat(document.getElementById('income').value);
    var expenses = parseFloat(document.getElementById('expenses').value);
    var interest = parseFloat(document.getElementById('interest').value) / 100;
    var years = parseFloat(document.getElementById('years').value);
    var propertyTax = parseFloat(document.getElementById('propertyTax').value);
  var homeownersInsurance = parseFloat(document.getElementById('homeownersInsurance').value);
  var hoaFees = parseFloat(document.getElementById('hoaFees').value);
  

    var monthlyIncome = income / 12;
            var monthlyIncomeAvailable = monthlyIncome - expenses;

            var loanAmountAffordability = (monthlyIncomeAvailable * 0.28) * 12;
            var loanAmountStretch = (monthlyIncomeAvailable * 0.36) * 12;
            var loanAmountAggressive = (monthlyIncomeAvailable * 0.42) * 12;

            var resultsHTML = "<h3>AFFORDABILITY BREAKDOWN</h3>";
            resultsHTML += "<p>Affordability: $" + numberWithCommas(loanAmountAffordability.toFixed(2)) + "</p>";
            resultsHTML += "<hr>";
            resultsHTML += "<p>Stretch: $" + numberWithCommas(loanAmountStretch.toFixed(2)) + "</p>";
            resultsHTML += "<hr>";
            resultsHTML += "<p>Aggressive: $" + numberWithCommas(loanAmountAggressive.toFixed(2)) + "</p>";

            document.getElementById("result").innerHTML = resultsHTML;
  
   // Convert annual interest rate to monthly interest rate
    var monthlyInterestRate = interest / 12 / 100;

    // Convert loan term from years to months
    var loanTermMonths = years * 12;

    // Calculate monthly principal and interest payment using the monthly payment formula
    var principalAndInterest = loanAmountAffordability * monthlyInterestRate / (1 - Math.pow(1 + monthlyInterestRate, -loanTermMonths));

    // Calculate monthly property tax
    var monthlyPropertyTax = propertyTax / 12;

    // Calculate monthly homeowners insurance
    var monthlyHomeownersInsurance = homeownersInsurance / 12;
  
    var pmi = (loanAmountAffordability * 0.5 / 12); 

    // Total monthly expenses including principal, interest, property taxes, homeowners insurance, HOA fees, and PMI
    var totalMonthlyPayment = principalAndInterest + monthlyPropertyTax + monthlyHomeownersInsurance + hoaFees + pmi;

    var totsHTML = "<p>AFFORDABILITY BREAKDOWN</p>";
            totsHTML += "<p>Principal and interest: $" + numberWithCommas(principalAndInterest.toFixed(2)) + "</p>";
            totsHTML += "<hr>";
            totsHTML += "<p>Property taxes: $" + numberWithCommas(monthlyPropertyTax.toFixed(2)) + "</p>";
            totsHTML += "<hr>";
            totsHTML += "<p>Homeowners insurance: $" + numberWithCommas(monthlyHomeownersInsurance.toFixed(2)) + "</p>";
            totsHTML += "<hr>";
            totsHTML += "<p>HOA fees: $" + numberWithCommas(hoaFees.toFixed(2)) + "</p>";
            totsHTML += "<hr>";
            totsHTML += "<p>Private mortgage insurance(PMI): $" + numberWithCommas(pmi.toFixed(2)) + "</p>";
            totsHTML += "<hr>";
            totsHTML += "<p>Total Monthly payment: $" + numberWithCommas(totalMonthlyPayment.toFixed(2)) + "</p>";

            document.getElementById("tot").innerHTML = totsHTML;
  


var image = document.getElementById("myImage");
      image.parentNode.removeChild(image);
  
  var data = {
    labels: ['Affordability', 'Stretch', 'Aggressive'],
    datasets: [{
      data: [loanAmountAffordability, loanAmountStretch, loanAmountAggressive],
      backgroundColor: ['#05800f','#f0891a', '#d11313'],
      hoverBackgroundColor: ['#05800f', '#f0891a', '#d11313']
    }]
  };
   

  var ctx = document.getElementById('pieChart').getContext('2d');
  var myPieChart = new Chart(ctx, {
    type: 'pie',
    data: data
  });
}

// JavaScript function to open tabs
function openTab(evt, tabName) {
  var i, tabContent, tabLinks;
  tabContent = document.getElementsByClassName("tab-content");
  for (i = 0; i < tabContent.length; i++) {
    tabContent[i].style.display = "none";
  }
  tabLinks = document.getElementsByClassName("tab");
  for (i = 0; i < tabLinks.length; i++) {
    tabLinks[i].className = tabLinks[i].className.replace(" active", "");
  }
  document.getElementById(tabName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Open the default tab on page load
document.addEventListener("DOMContentLoaded", function() {
  document.getElementById("defaultOpen").click();
});
// Get the info button and modal
var infoButton = document.getElementById("infoButton");
var infoModal = document.getElementById("infoModal");

// When the user clicks the button, display the modal
infoButton.onclick = function() {
    infoModal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
var close = document.getElementsByClassName("close")[0];
close.onclick = function() {
    infoModal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == infoModal) {
        infoModal.style.display = "none";
    }
}




function addDollarSign(inputField) {
  var value = inputField.value;
  // Remove existing dollar signs and commas
  value = value.replace(/\$/g, '').replace(/,/g, '');
  // Add dollar sign to the beginning
  inputField.value = "$" + value;
}

function showInfo(event) {
  alert("Info button clicked");
}